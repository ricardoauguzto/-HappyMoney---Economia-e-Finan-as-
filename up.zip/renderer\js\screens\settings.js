import { api } from '../api.js';
import { abrirModal, botao, toast } from '../ui.js';

export function abrirConfiguracoes() {
  const corpo = document.createElement('div');

  const tituloLocal = document.createElement('strong');
  tituloLocal.style.display = 'block';
  tituloLocal.style.marginBottom = '6px';
  tituloLocal.textContent = 'Localização dos dados';

  const paragrafoLocal = document.createElement('p');
  paragrafoLocal.className = 'aviso';
  paragrafoLocal.textContent =
    'Tudo é armazenado apenas neste computador. Nada é enviado à internet.';

  let caminhoPlanilhas = '';
  const caminhoCaixa = document.createElement('div');
  caminhoCaixa.className = 'caminho-mono';
  caminhoCaixa.textContent = 'Carregando…';

  const botaoPasta = botao({
    label: 'Abrir pasta de planilhas',
    primario: false,
    onClick: () => api.abrirPasta(caminhoPlanilhas),
  });
  botaoPasta.style.width = '100%';
  botaoPasta.style.justifyContent = 'center';

  corpo.appendChild(tituloLocal);
  corpo.appendChild(paragrafoLocal);
  corpo.appendChild(caminhoCaixa);
  const espaco = document.createElement('div');
  espaco.style.height = '10px';
  corpo.appendChild(espaco);
  corpo.appendChild(botaoPasta);

  const divisao = document.createElement('hr');
  divisao.style.border = 'none';
  divisao.style.borderTop = '1px solid var(--borda)';
  divisao.style.margin = '22px 0';
  corpo.appendChild(divisao);

  const tituloAssoc = document.createElement('strong');
  tituloAssoc.style.display = 'block';
  tituloAssoc.style.marginBottom = '6px';
  tituloAssoc.textContent = 'Arquivos .sk no Windows';

  const paragrafoAssoc = document.createElement('p');
  paragrafoAssoc.className = 'aviso';
  paragrafoAssoc.textContent =
    'Depois de associados, basta dar dois cliques em um arquivo .sk para abri-lo no HappyMoney.';

  let pillAssoc = document.createElement('span');
  pillAssoc.className = 'pill pill-suave';
  pillAssoc.id = 'pill-assoc';
  pillAssoc.textContent = 'Verificando…';

  const botaoAssoc = botao({
    label: 'Associar arquivos .sk',
    primario: true,
    onClick: async () => {
      const resultado = await api.registrarAssociacao();
      if (resultado.ok) {
        toast('Arquivos .sk associados ao HappyMoney.');
        atualizarPill();
      } else {
        toast('Não foi possível associar os arquivos .sk.', 'erro');
      }
    },
  });
  botaoAssoc.style.width = '100%';
  botaoAssoc.style.justifyContent = 'center';

  corpo.appendChild(tituloAssoc);
  corpo.appendChild(paragrafoAssoc);
  corpo.appendChild(pillAssoc);
  const espaco2 = document.createElement('div');
  espaco2.style.height = '12px';
  corpo.appendChild(espaco2);
  corpo.appendChild(botaoAssoc);

  const divisao2 = document.createElement('hr');
  divisao2.style.border = 'none';
  divisao2.style.borderTop = '1px solid var(--borda)';
  divisao2.style.margin = '22px 0';
  corpo.appendChild(divisao2);

  const tituloSobre = document.createElement('strong');
  tituloSobre.style.display = 'block';
  tituloSobre.style.marginBottom = '6px';
  tituloSobre.textContent = 'Sobre o HappyMoney';
  const paragrafoSobre = document.createElement('p');
  paragrafoSobre.className = 'aviso';
  paragrafoSobre.textContent =
    'Versão 1.0.0 · Plataforma pessoal de economia · 100% offline · Desenvolvido por Adenstack.';
  corpo.appendChild(tituloSobre);
  corpo.appendChild(paragrafoSobre);

  abrirModal({
    titulo: 'Configurações',
    sub: 'Seus dados ficam somente neste computador.',
    corpo,
    largura: 520,
    rodape: [botao({ label: 'Fechar' })],
  });

  async function atualizarPill() {
    const verificado = await api.verificarAssociacao().catch(() => null);
    const nova = document.getElementById('pill-assoc');
    if (!nova) return;
    if (verificado && verificado.associada) {
      nova.className = 'pill pill-verde';
      nova.textContent = 'Associados ✓';
    } else {
      nova.className = 'pill pill-suave';
      nova.textContent = 'Não associados';
    }
  }

  api.diretorios().then((d) => {
    caminhoPlanilhas = d.planilhas;
    caminhoCaixa.textContent = d.planilhas;
  });
  atualizarPill();
}