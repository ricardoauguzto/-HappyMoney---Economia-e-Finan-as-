import { icone } from './icons.js';

let modalAtivo = null;

export function abrirModal({ titulo, sub, corpo, rodape, largura }) {
  fecharModal();

  const root = document.getElementById('modal-root');
  root.hidden = false;

  const cartao = document.createElement('div');
  cartao.className = 'modal-card';
  if (largura) cartao.style.maxWidth = largura + 'px';

  const cabecalho = document.createElement('div');
  cabecalho.className = 'modal-head';

  const tituloCaixa = document.createElement('div');
  const tituloEl = document.createElement('h2');
  tituloEl.className = 'modal-title';
  tituloEl.textContent = titulo;
  tituloCaixa.appendChild(tituloEl);
  if (sub) {
    const subEl = document.createElement('p');
    subEl.className = 'modal-sub';
    subEl.textContent = sub;
    tituloCaixa.appendChild(subEl);
  }

  const fecharBtn = document.createElement('button');
  fecharBtn.className = 'icon-btn ghost';
  fecharBtn.title = 'Fechar';
  fecharBtn.innerHTML = icone('x');
  fecharBtn.addEventListener('click', fecharModal);

  cabecalho.appendChild(tituloCaixa);
  cabecalho.appendChild(fecharBtn);

  const corpoEl = document.createElement('div');
  corpoEl.className = 'modal-corpo';
  if (typeof corpo === 'string') corpoEl.innerHTML = corpo;
  else if (corpo) corpoEl.appendChild(corpo);

  const rodapeEl = document.createElement('div');
  rodapeEl.className = 'modal-foot';
  if (Array.isArray(rodape)) {
    for (const botao of rodape) {
      rodapeEl.appendChild(botao);
    }
  }

  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  cartao.appendChild(cabecalho);
  cartao.appendChild(corpoEl);
  cartao.appendChild(rodapeEl);
  root.appendChild(backdrop);
  root.appendChild(cartao);
  modalAtivo = cartao;

  root.addEventListener('click', (e) => {
    if (e.target === backdrop) fecharModal();
  });

  const aoFechar = (e) => {
    if (e.key === 'Escape') {
      fecharModal();
      window.removeEventListener('keydown', aoFechar);
    }
  };
  window.addEventListener('keydown', aoFechar);

  requestAnimationFrame(() => {
    const foco = cartao.querySelector('[autofocus], input, button');
    if (foco) foco.focus();
  });

  return cartao;
}

export function fecharModal() {
  const root = document.getElementById('modal-root');
  if (root) {
    root.innerHTML = '';
    root.hidden = true;
  }
  modalAtivo = null;
}

export function botao({ tipo, label, primario, perigo, onClick, reactivo }) {
  const el = document.createElement('button');
  el.type = 'button';
  el.className = 'btn ' + (perigo ? 'btn-perigo' : primario ? 'btn-primario' : 'btn-suave');
  el.textContent = label;
  el.addEventListener('click', () => {
    if (typeof onClick === 'function') onClick(el);
  });
  return el;
}

export function confirmar({ titulo, mensagem, okLabel, perigo, onOk, cancelLabel }) {
  const corpo = document.createElement('div');
  const p = document.createElement('p');
  p.className = 'aviso';
  p.textContent = mensagem;
  corpo.appendChild(p);

  abrirModal({
    titulo,
    corpo,
    largura: 420,
    rodape: [
      botao({
        label: cancelLabel || 'Cancelar',
        onClick: fecharModal,
      }),
      botao({
        label: okLabel || 'Confirmar',
        perigo: perigo !== false,
        primario: perigo === false,
        onClick: (el) => {
          fecharModal();
          if (typeof onOk === 'function') onOk(el);
        },
      }),
    ],
  });
}

export function dialogar({ titulo, sub, mensagem, opcoes }) {
  const corpo = document.createElement('div');
  const p = document.createElement('p');
  p.className = 'aviso';
  p.textContent = mensagem;
  corpo.appendChild(p);

  abrirModal({
    titulo,
    sub,
    corpo,
    largura: 440,
    rodape: opcoes.map((o) =>
      botao({
        label: o.label,
        primario: o.primario,
        perigo: o.perigo,
        onClick: () => {
          fecharModal();
          if (typeof o.onClick === 'function') o.onClick();
        },
      })
    ),
  });
}

export function toast(mensagem, tipo = 'sucesso') {
  const root = document.getElementById('toast-root');
  const el = document.createElement('div');
  el.className = 'toast ' + tipo;
  const iconeNome = tipo === 'erro' ? 'alerta' : tipo === 'info' ? 'info' : 'checado';
  el.innerHTML = icone(iconeNome);
  const texto = document.createElement('span');
  texto.textContent = mensagem;
  el.appendChild(texto);
  root.appendChild(el);

  setTimeout(() => {
    el.classList.add('saindo');
    setTimeout(() => el.remove(), 260);
  }, 2600);
}

export function campoTexto({ id, label, placeholder, valor, autofoco, tipo }) {
  const wrapper = document.createElement('div');
  wrapper.className = 'campo';

  const rotulo = document.createElement('label');
  rotulo.htmlFor = id;
  rotulo.textContent = label;

  const input = document.createElement('input');
  input.id = id;
  input.type = tipo || 'text';
  input.className = 'entrada';
  input.placeholder = placeholder || '';
  input.value = valor || '';
  if (autofoco) input.setAttribute('autofocus', '');

  wrapper.appendChild(rotulo);
  wrapper.appendChild(input);
  return { wrapper, input };
}

export function campoDinheiro({ id, label, placeholder, valorCentavos }) {
  const base = campoTexto({
    id,
    label,
    placeholder: placeholder || 'R$ 0,00',
    autofoco: true,
  });
  const input = base.input;
  vincularCampoDinheiro(input);
  if (valorCentavos) definirCentavos(input, valorCentavos);
  return base;
}

import { vincularCampoDinheiro, definirCentavos } from './money.js';