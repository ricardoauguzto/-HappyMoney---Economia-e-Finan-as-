export const api =
  typeof window !== 'undefined' && window.happyMoney
    ? window.happyMoney
    : null;

export function apiDisponivel() {
  return !!api;
}