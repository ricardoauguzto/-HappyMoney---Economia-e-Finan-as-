import { api } from './api.js';
import { icone } from './icons.js';
import { abrirModal, botao, toast, fecharModal } from './ui.js';
import { renderizarDashboard } from './screens/dashboard.js';
import { renderizarPlanilha } from './screens/spreadsheet.js';
import { abrirConfiguracoes } from './screens/settings.js';

const tela = document.getElementById('tela');

export const estado = {
  telaAtual: 'dashboard',
  sheet: null,
  caminho: null,
  dirty: false,
  logoCarregada: false,
};

export const ctx = {
  estado,
  tela,
  irPara,
};

async function iniciar() {
  const btnConfig = document.getElementById('btn-configuracoes');
  btnConfig.innerHTML = icone('engrenagem');
  btnConfig.addEventListener('click', abrirConfiguracoes);

  const tempoMinimo = new Promise((r) => setTimeout(r, 2800));

  const prepararAplicativo = (async () => {
    await carregarLogo();
    prepararEventosGlobais();
    await irPara('dashboard');
  })();

  await Promise.all([prepararAplicativo, tempoMinimo]);
  esconderSplash();
  registrarSmoke();
}

function esconderSplash() {
  const splash = document.getElementById('splash');
  if (!splash) return;
  splash.classList.add('splash-saindo');
  setTimeout(() => {
    if (splash.parentNode) splash.parentNode.removeChild(splash);
  }, 480);
}

async function carregarLogo() {
  const logo = document.getElementById('logo');
  const splashLogo = document.getElementById('splash-logo');
  const marcarCarregada = () => {
    estado.logoCarregada = true;
  };
  const marcarFalha = () => {
    estado.logoCarregada = false;
  };
  try {
    const url = await api.logoUrl();
    if (url) {
      logo.onload = marcarCarregada;
      logo.onerror = marcarFalha;
      splashLogo.onload = marcarCarregada;
      splashLogo.onerror = marcarFalha;
      logo.src = url;
      splashLogo.src = url;
    } else {
      logo.style.display = 'none';
      logo.alt = 'HappyMoney';
    }
  } catch {
    logo.style.display = 'none';
    logo.alt = 'HappyMoney';
  }
}

function prepararEventosGlobais() {
  if (api.onAbrirArquivo) {
    api.onAbrirArquivo(async (caminho) => {
      await abrirArquivoExterno(caminho);
    });
  }
  if (api.onNovaPlanilhaMenu) {
    api.onNovaPlanilhaMenu(async () => {
      fecharModal();
      await irPara('dashboard');
      tela.dispatchEvent(new CustomEvent('hm:nova-planilha'));
    });
  }
  if (api.onSobreMenu) {
    api.onSobreMenu(() => abrirSobre());
  }
}

function abrirSobre() {
  const corpo = document.createElement('div');

  const logo = document.createElement('img');
  logo.className = 'sobre-logo';
  logo.alt = 'HappyMoney';
  const logoTopbar = document.getElementById('logo');
  if (logoTopbar && logoTopbar.src) logo.src = logoTopbar.src;
  logo.style.display = 'block';
  logo.style.width = '72px';
  logo.style.height = '72px';
  logo.style.borderRadius = '18px';
  logo.style.margin = '0 auto 14px';
  logo.style.boxShadow = '0 8px 20px rgba(37, 99, 235, 0.25)';

  const nome = document.createElement('div');
  nome.className = 'sobre-nome';
  nome.style.textAlign = 'center';
  nome.style.fontSize = '18px';
  nome.style.fontWeight = '750';
  nome.textContent = 'HappyMoney 1.0.0';

  const descricao = document.createElement('p');
  descricao.className = 'aviso';
  descricao.style.textAlign = 'center';
  descricao.textContent =
    'Plataforma pessoal de economia e planejamento financeiro.';

  const offline = document.createElement('p');
  offline.className = 'aviso';
  offline.style.textAlign = 'center';
  offline.textContent = '100% offline — seus dados ficam somente neste computador.';

  const rodape = document.createElement('p');
  rodape.className = 'aviso';
  rodape.style.textAlign = 'center';
  rodape.textContent = 'Escrito em Electron · Desenvolvido por Adenstack.';

  corpo.appendChild(logo);
  corpo.appendChild(nome);
  corpo.appendChild(descricao);
  corpo.appendChild(offline);
  corpo.appendChild(rodape);

  abrirModal({
    titulo: 'Sobre o HappyMoney',
    corpo,
    largura: 400,
    rodape: [botao({ label: 'Fechar' })],
  });
}

async function abrirArquivoExterno(caminho) {
  try {
    const { sheet, caminho: caminhoResolvido } = await api.lerPlanilha(caminho);
    await irPara('planilha', { sheet, caminho: caminhoResolvido });
    toast('Planilha "' + sheet.nome + '" aberta.', 'info');
  } catch (err) {
    toast(err.message || 'Não foi possível abrir o arquivo .sk.', 'erro');
  }
}

async function irPara(nome, dados) {
  estado.telaAtual = nome;

  if (nome === 'dashboard') {
    estado.sheet = null;
    estado.caminho = null;
    estado.dirty = false;
    await renderizarDashboard(tela, ctx);
    return;
  }

  if (nome === 'planilha' && dados) {
    estado.sheet = dados.sheet;
    estado.caminho = dados.caminho;
    renderizarPlanilha(tela, ctx);
    return;
  }

  estado.telaAtual = 'dashboard';
  await renderizarDashboard(tela, ctx);
}

function registrarSmoke() {
  window.__smokeResult = async () => {
    const detalhes = [];
    let ok = true;
    const checar = (nome, condicao, nota) => {
      detalhes.push({ nome, ok: !!condicao, nota: nota || '' });
      if (!condicao) ok = false;
    };

    try {
      checar('preload-happymoney', typeof api === 'object' && !!api);

      const listaInicial = await api.listarPlanilhas();
      checar('listar-vazio', Array.isArray(listaInicial), 'qtd=' + listaInicial.length);

      const criada = await api.criarPlanilha({
        nome: 'Smoke Teste',
        salarioBruto: 3000,
      });
      checar(
        'criar-planilha',
        !!criada && !!criada.caminho && criada.caminho.toLowerCase().endsWith('.sk'),
        criada.caminho || ''
      );

      const viaLista = await api.listarPlanilhas();
      checar(
        'planilha-na-lista',
        viaLista.some((p) => p.id === criada.sheet.id),
        'total=' + viaLista.length
      );

      const lida = await api.lerPlanilha(criada.caminho);
      checar(
        'ler-planilha',
        !!lida.sheet && lida.sheet.salarioBruto === 3000 && lida.sheet.nome === 'Smoke Teste'
      );

      // Garante despesas e recalcula salário disponível
      const comDespesa = {
        ...lida.sheet,
        despesas: [
          { id: 'd1', nome: 'Faculdade', valor: 197 },
          { id: 'd2', nome: 'Netflix', valor: 22 },
          { id: 'd3', nome: 'Mercado', valor: 350 },
        ],
      };
      const salva = await api.salvarPlanilha({ sheet: comDespesa, caminho: criada.caminho });
      checar('salvar-despesas', salva.sheet.despesas.length === 3);
      checar(
        'resumo-snapshot',
        salva.sheet.resumo && salva.sheet.resumo.total === 569,
        'total=' + (salva.sheet.resumo && salva.sheet.resumo.total)
      );

      await irPara('planilha', { sheet: salva.sheet, caminho: criada.caminho });

      const heroValor = document.getElementById('hero-valor');
      const barra = document.getElementById('barra-preenchimento');
      const totalEl = document.getElementById('total-despesas');
      checar('tela-planilha', !!heroValor && !!barra && !!totalEl, 'hero=' + (heroValor && heroValor.textContent));
      checar('hero-correto', heroValor && heroValor.textContent.includes('2.431,00'), heroValor && heroValor.textContent);
      checar('barra-81', barra && Math.round(parseFloat(barra.style.width)) === 81, 'width=' + (barra && barra.style.width));
      checar('total-correto', totalEl && totalEl.textContent.includes('569,00'), totalEl && totalEl.textContent);

      const heroQtde = document.querySelectorAll('#lista-despesas .despesa').length;
      checar('lista-3-despesas', heroQtde === 3, 'qtd=' + heroQtde);

      await api.excluirPlanilha(criada.caminho);
      const listaFinal = await api.listarPlanilhas();
      checar(
        'excluir-planilha',
        !listaFinal.some((p) => p.id === criada.sheet.id),
        'total=' + listaFinal.length
      );

      await irPara('dashboard');
      const saudacao = document.querySelector('.saudacao h1');
      checar('dashboard-ok', !!saudacao && saudacao.textContent.includes('Olá'));

      checar('logo-carregada', !!estado.logoCarregada);

      await executarFluxoUI(checar);
    } catch (err) {
      ok = false;
      detalhes.push({ nome: 'excecao', ok: false, nota: String((err && err.message) || err) });
    }

    return { ok, detalhes };
  };
}

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

async function clicar(seletor, texto) {
  const alvo = texto
    ? [...document.querySelectorAll(seletor)].find((b) =>
        b.textContent.includes(texto)
      )
    : document.querySelector(seletor);
  if (alvo) alvo.click();
  await esperar(120);
  return alvo;
}

async function preencherInput(id, valor) {
  const input = document.getElementById(id);
  if (!input) return null;
  input.value = valor;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  await esperar(60);
  return input;
}

async function submeterModal(botaoTexto) {
  return clicar('.modal-foot button', botaoTexto);
}

async function executarFluxoUI(checar) {
  const splashAtual = (function () {
    const s = document.getElementById('splash');
    return !s || s.classList.contains('splash-saindo');
  })();
  checar('ui-splash-removida', splashAtual);

  // Hit-testing real: o clique deve chegar ao botão, e não a um overlay invisível
  const achaBotaoReal = (btn) => {
    if (!btn) return false;
    const r = btn.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const noTopo = document.elementFromPoint(cx, cy);
    return !!noTopo && (noTopo === btn || btn.contains(noTopo));
  };

  checar('ui-clique-real-nova', achaBotaoReal(document.querySelector('.btn-nova')));
  checar(
    'ui-nenhum-overlay',
    !(['modal-backdrop', 'modal-root']).includes((document.elementFromPoint(20, 200) || {}).className)
  );

  // Criar planilha pelo formulário
  await clicar('.btn-nova');
  checar('ui-modal-criar', !!document.getElementById('f-nome-planilha'));
  const modalCard = () => document.querySelector('.modal-card');
  checar('ui-overlay-abre', (function () {
    const m = modalCard();
    if (!m) return false;
    const r = m.getBoundingClientRect();
    const t = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return !!t && (m === t || m.contains(t));
  })());

  // Cancelar fecha o modal sem criar nada
  await clicar('.modal-foot .btn-suave');
  await esperar(200);
  checar(
    'ui-cancelar-fecha',
    !document.getElementById('f-nome-planilha'),
    document.getElementById('modal-root') ? String(document.getElementById('modal-root').hidden) : 'sem-root'
  );

  await clicar('.btn-nova');
  checar('ui-modal-criar-2', !!document.getElementById('f-nome-planilha'));
  await preencherInput('f-nome-planilha', 'Flow UI');
  await preencherInput('f-salario-planilha', '2500');
  await submeterModal('Criar planilha');
  await esperar(400);
  checar(
    'ui-abriu-planilha',
    !!document.getElementById('hero-valor'),
    'hero=' + (document.getElementById('hero-valor') || {}).textContent
  );
  checar(
    'ui-salario-2500',
    (document.getElementById('valor-salario') || {}).textContent === 'R$\u00a02.500,00',
    (document.getElementById('valor-salario') || {}).textContent
  );

  // Adicionar despesa pelo formulário
  await clicar('.botao-adicionar');
  checar('ui-modal-despesa', !!document.getElementById('f-nome-despesa'));
  await preencherInput('f-nome-despesa', 'Assinatura');
  await preencherInput('f-valor-despesa', '100');
  await submeterModal('Adicionar despesa');
  await esperar(250);
  checar(
    'ui-despesa-adicionada',
    document.querySelectorAll('#lista-despesas .despesa').length === 1
  );
  checar(
    'ui-modal-fechado',
    document.getElementById('modal-root') ? document.getElementById('modal-root').hidden : false
  );

  // Cards do resumo não podem deixar texto/barra vazarem pela borda
  checar('ui-card-comprometido-enquadra', (function () {
    const pai = document.getElementById('card-comprometido');
    if (!pai) return false;
    const pr = pai.getBoundingClientRect();
    const filhos = pai.querySelectorAll(':scope > *');
    if (filhos.length === 0) return false;
    for (const el of filhos) {
      const r = el.getBoundingClientRect();
      if (Math.abs(r.left - pr.left) < 6 && Math.abs(r.right - pr.right) < 6) return false;
      if (r.right > pr.right + 1 || r.left < pr.left - 1) return false;
    }
    return true;
  })());

  // Salvar
  await clicar('.pl-barra button', 'Salvar');
  await esperar(200);
  checar(
    'ui-salvo',
    (document.getElementById('status-pill') || {}).textContent.includes('Salvo'),
    (document.getElementById('status-pill') || {}).textContent
  );

  // Voltar com tela limpa (sem diálogo)
  await clicar('.pl-barra button', 'Voltar');
  await esperar(300);
  checar(
    'ui-voltou-dashboard',
    !!document.querySelector('.grade-planilhas .card-planilha'),
    'cards=' + document.querySelectorAll('.grade-planilhas .card-planilha').length
  );

  // Abrir de novo pelo card e editar salário
  const cardFlow = [...document.querySelectorAll('.card-planilha')].find((c) =>
    c.textContent.includes('Flow UI')
  );
  checar('ui-card-flow', !!cardFlow);
  if (cardFlow) {
    cardFlow.querySelector('.pl-abrir').click();
    await esperar(300);
  }
  checar('ui-reabriu', !!document.getElementById('hero-valor'));

  await clicar('[data-editar-salario]');
  await preencherInput('f-salario-planilha', '2800');
  await submeterModal('Salvar alterações');
  await esperar(300);
  checar(
    'ui-salario-editado',
    (document.getElementById('hero-valor') || {}).textContent === 'R$\u00a02.700,00',
    (document.getElementById('hero-valor') || {}).textContent
  );

  // Voltar e excluir via card
  await clicar('.pl-barra button', 'Salvar');
  await esperar(200);
  await clicar('.pl-barra button', 'Voltar');
  await esperar(200);
  checar('ui-tela-limpa', !document.getElementById('status-pill'));

  const cardParaExcluir = [...document.querySelectorAll('.card-planilha')].find((c) =>
    c.textContent.includes('Flow UI')
  );
  checar('ui-card-excluir', !!cardParaExcluir);
  if (cardParaExcluir) {
    cardParaExcluir.querySelector('[data-excluir]').click();
    await esperar(150);
    const temConfirmacao = [...document.querySelectorAll('.modal-foot button')].some((b) =>
      b.textContent.includes('Excluir')
    );
    checar('ui-modal-confirma-excluir', temConfirmacao);
    await submeterModal('Excluir');
    await esperar(300);
  }
  checar(
    'ui-excluido',
    ![...document.querySelectorAll('.card-planilha')].some((c) =>
      c.textContent.includes('Flow UI')
    )
  );

  // Configurações
  await clicar('#btn-configuracoes');
  await esperar(350);
  const tituloConfig =
    document.querySelector('.modal-card .modal-title') || {};
  checar(
    'ui-config-modal',
    tituloConfig.textContent && tituloConfig.textContent.includes('Configurações'),
    tituloConfig.textContent
  );
  checar(
    'ui-config-caminho',
    ((document.querySelector('.caminho-mono') || {}).textContent || '').includes('Planilhas'),
    (document.querySelector('.caminho-mono') || {}).textContent
  );
  const pillAssoc = document.querySelector('#pill-assoc');
  checar(
    'ui-config-assoc',
    !!pillAssoc && !pillAssoc.textContent.includes('Verificando'),
    pillAssoc && pillAssoc.textContent
  );
  await clicar('.modal-foot button', 'Fechar');
  await esperar(150);

  checar('ui-dashboard-final', !!document.querySelector('.saudacao h1'));
}

iniciar();