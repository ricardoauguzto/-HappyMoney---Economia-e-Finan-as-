import { api } from '../api.js';
import { icone } from '../icons.js';
import { formatarValor, centavosDeValor, valorDeCentavos } from '../money.js';
import { confirmar, toast, fecharModal } from '../ui.js';
import { formularioPlanilha } from './formularios.js';

export async function renderizarDashboard(tela, ctx) {
  tela.innerHTML = '';

  const wraper = document.createElement('div');
  wraper.className = 'wraper animar-tela';
  tela.appendChild(wraper);

  const saudacao = document.createElement('section');
  saudacao.className = 'saudacao';
  saudacao.innerHTML =
    '<h1>Olá! 👋</h1>' +
    '<p>Organize sua economia de forma simples.</p>';
  wraper.appendChild(saudacao);

  const btnNova = document.createElement('button');
  btnNova.className = 'btn btn-primario btn-lg btn-nova';
  btnNova.innerHTML = icone('mais', 20) + 'Nova planilha de economia';
  btnNova.addEventListener('click', () => abrirCriarPlanilha(ctx));
  wraper.appendChild(btnNova);

  const areaResumo = document.createElement('section');
  areaResumo.className = 'resumo-rapido';
  wraper.appendChild(areaResumo);

  const areaLista = document.createElement('section');

  const secaoHeader = document.createElement('div');
  secaoHeader.className = 'secao-titulo';
  secaoHeader.innerHTML =
    '<h2>Minhas planilhas</h2><span class="contagem" id="contagem-planilhas"></span>';
  areaLista.appendChild(secaoHeader);

  const grade = document.createElement('div');
  grade.className = 'grade-planilhas';
  grade.id = 'grade-planilhas';
  areaLista.appendChild(grade);
  wraper.appendChild(areaLista);

  await atualizarConteudo(wraper, ctx);

  tela.addEventListener('hm:nova-planilha', () => abrirCriarPlanilha(ctx), {
    once: true,
  });
}

async function atualizarConteudo(wraper, ctx) {
  let planilhas = [];
  try {
    planilhas = await api.listarPlanilhas();
  } catch (err) {
    toast(err.message || 'Não foi possível listar as planilhas.', 'erro');
  }

  const contagem = wraper.querySelector('#contagem-planilhas');
  if (contagem) {
    contagem.textContent =
      planilhas.length === 0
        ? ''
        : planilhas.length === 1
          ? '1 planilha'
          : planilhas.length + ' planilhas';
  }

  renderizarResumo(wraper, planilhas);
  renderizarGrade(wraper, planilhas, ctx);
}

function renderizarResumo(wraper, planilhas) {
  const area = wraper.querySelector('.resumo-rapido');
  area.innerHTML = '';

  const salarioTotal = planilhas.reduce(
    (s, p) => s + centavosDeValor(p.salarioBruto),
    0
  );
  const despesasTotal = planilhas.reduce(
    (s, p) => s + centavosDeValor(p.totalDespesas),
    0
  );
  const disponivelTotal = planilhas.reduce(
    (s, p) => s + centavosDeValor(p.disponivel),
    0
  );

  const cartao = (iconeNome, rotulo, valor, classeCor) => {
    const el = document.createElement('div');
    el.className = 'card resumo-card';
    el.innerHTML =
      '<div class="resumo-icone">' +
      icone(iconeNome) +
      '</div>' +
      '<div><div class="resumo-valor ' +
      (classeCor || '') +
      '">' +
      valor +
      '</div><div class="resumo-rotulo">' +
      rotulo +
      '</div></div>';
    return el;
  };

  area.appendChild(cartao('card', 'Planilhas', String(planilhas.length)));
  area.appendChild(
    cartao('card', 'Salários informados', formatarValor(valorDeCentavos(salarioTotal)))
  );
  area.appendChild(
    cartao('card', 'Total de despesas', formatarValor(valorDeCentavos(despesasTotal)))
  );
  area.appendChild(
    cartao(
      'card',
      'Disponível nas planilhas',
      formatarValor(valorDeCentavos(disponivelTotal)),
      disponivelTotal < 0 ? 'vermelho' : 'verde-escuro'
    )
  );
}

function renderizarGrade(wraper, planilhas, ctx) {
  const grade = wraper.querySelector('#grade-planilhas');
  grade.innerHTML = '';

  if (planilhas.length === 0) {
    const vazio = document.createElement('div');
    vazio.className = 'vazio';
    vazio.innerHTML =
      '<div class="vazio-emoji">🪙</div>' +
      '<h3>Nenhuma planilha ainda</h3>' +
      '<p>Sua economia começa aqui. Crie sua primeira planilha agora.</p>';

    const btn = document.createElement('button');
    btn.className = 'btn btn-primario btn-bloco';
    btn.style.maxWidth = '300px';
    btn.style.margin = '0 auto';
    btn.innerHTML = icone('mais') + 'Criar planilha';
    btn.addEventListener('click', () => abrirCriarPlanilha(ctx));
    vazio.appendChild(btn);
    grade.appendChild(vazio);
    return;
  }

  for (const planilha of planilhas) {
    grade.appendChild(criarCardPlanilha(planilha, ctx));
  }
}

function criarCardPlanilha(planilha, ctx) {
  const card = document.createElement('article');
  card.className = 'card-planilha';

  const qtdTexto =
    planilha.qtdDespesas === 0
      ? 'sem despesas'
      : planilha.qtdDespesas === 1
        ? '1 despesa'
        : planilha.qtdDespesas + ' despesas';

  const statusTexto =
    planilha.disponivel < 0
      ? 'no vermelho'
      : planilha.disponivel >= planilha.salarioBruto - 0.001
        ? 'economizando'
        : 'em dia';

  const disponivelClasse = planilha.disponivel < 0 ? 'neg' : 'ok';

  card.innerHTML =
    '<div class="pl-topo">' +
    '<div class="pl-icone">' +
    icone('card') +
    '</div>' +
    '<div class="pl-acoes">' +
    '<button type="button" data-editar class="icon-btn ghost" title="Editar planilha">' +
    icone('lapis') +
    '</button>' +
    '<button type="button" data-excluir class="icon-btn ghost perigo" title="Excluir planilha">' +
    icone('lixeira') +
    '</button>' +
    '</div></div>' +
    '<h3 class="pl-nome"></h3>' +
    '<dl class="pl-dados">' +
    '<div><dt>Salário</dt><dd></dd></div>' +
    '<div><dt>Despesas</dt><dd></dd></div>' +
    '<div><dt>Disponível</dt><dd class="' +
    disponivelClasse +
    '"></dd></div>' +
    '<div><dt>Status</dt><dd></dd></div>' +
    '</dl>';

  const valorElementos = card.querySelectorAll('.pl-dados dd');
  card.querySelector('.pl-nome').textContent = planilha.nome;
  valorElementos[0].textContent = formatarValor(planilha.salarioBruto);
  valorElementos[1].textContent =
    qtdTexto + ' · ' + formatarValor(planilha.totalDespesas);
  valorElementos[2].textContent = formatarValor(planilha.disponivel);
  valorElementos[3].textContent = statusTexto;

  const btnAbrir = document.createElement('button');
  btnAbrir.type = 'button';
  btnAbrir.className = 'btn btn-primario pl-abrir';
  btnAbrir.innerHTML = 'Abrir ' + icone('setaDir');
  btnAbrir.addEventListener('click', () => abrirPlanilha(planilha, ctx));
  card.appendChild(btnAbrir);

  card.querySelector('[data-editar]').addEventListener('click', () =>
    abrirEditarPlanilha(planilha, ctx)
  );
  card.querySelector('[data-excluir]').addEventListener('click', () =>
    excluirPlanilha(planilha, ctx)
  );

  return card;
}

async function abrirPlanilha(planilha, ctx) {
  try {
    const { sheet, caminho } = await api.lerPlanilha(planilha.caminho);
    ctx.irPara('planilha', { sheet, caminho });
  } catch (err) {
    toast(err.message || 'Não foi possível abrir a planilha.', 'erro');
  }
}

function abrirCriarPlanilha(ctx) {
  formularioPlanilha({
    onSalvar: async (dados) => {
      try {
        const criada = await api.criarPlanilha(dados);
        fecharModal();
        toast('Planilha criada com sucesso.');
        ctx.irPara('planilha', criada);
      } catch (err) {
        toast(err.message || 'Não foi possível criar a planilha.', 'erro');
      }
    },
  });
}

async function abrirEditarPlanilha(planilha, ctx) {
  let completa;
  try {
    completa = await api.lerPlanilha(planilha.caminho);
  } catch (err) {
    toast(err.message || 'Não foi possível abrir a planilha.', 'erro');
    return;
  }

  formularioPlanilha({
    planilha: completa.sheet,
    onSalvar: async (dados) => {
      try {
        const nova = {
          ...completa.sheet,
          nome: dados.nome,
          salarioBruto: dados.salarioBruto,
        };
        const resultado = await api.salvarPlanilha({
          sheet: nova,
          caminho: completa.caminho,
        });
        fecharModal();
        toast('Planilha atualizada.');
        if (ctx.estado.sheet && ctx.estado.sheet.id === nova.id) {
          ctx.estado.sheet = resultado.sheet;
        }
        if (ctx.tela) await atualizarConteudo(wraperDoTela(ctx.tela), ctx);
      } catch (err) {
        toast(err.message || 'Não foi possível salvar.', 'erro');
      }
    },
  });
}

function wraperDoTela(tela) {
  return tela.querySelector('.wraper');
}

function excluirPlanilha(planilha, ctx) {
  confirmar({
    titulo: 'Excluir planilha',
    mensagem:
      'A planilha "' +
      planilha.nome +
      '" e todas as suas despesas serão excluídas permanentemente. Deseja continuar?',
    okLabel: 'Excluir',
    onOk: async () => {
      try {
        await api.excluirPlanilha(planilha.caminho);
        toast('Planilha excluída.');
        if (ctx.estado.sheet && ctx.estado.sheet.id === planilha.id) {
          ctx.estado.sheet = null;
          ctx.estado.caminho = null;
          ctx.estado.dirty = false;
          ctx.irPara('dashboard');
          return;
        }
        if (ctx.tela) await atualizarConteudo(wraperDoTela(ctx.tela), ctx);
      } catch (err) {
        toast(err.message || 'Não foi possível excluir.', 'erro');
      }
    },
  });
}