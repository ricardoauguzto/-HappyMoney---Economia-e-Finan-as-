import { abrirModal, botao, campoTexto, campoDinheiro, fecharModal } from '../ui.js';
import { centavosDeValor, valorDeCentavos, obterCentavos } from '../money.js';

export function formularioPlanilha({ planilha, onSalvar }) {
  const titulo = planilha
    ? 'Editar planilha'
    : 'Nova planilha de economia';
  const sub = planilha
    ? 'Ajuste o nome e o salário bruto.'
    : 'Dê um nome e informe seu salário bruto.';

  const nome = campoTexto({
    id: 'f-nome-planilha',
    label: 'Nome da planilha',
    placeholder: 'Ex.: Setembro 2026',
    valor: planilha ? planilha.nome : '',
    autofoco: !planilha,
  });

  const salario = campoDinheiro({
    id: 'f-salario-planilha',
    label: 'Salário bruto',
    placeholder: 'R$ 0,00',
    valorCentavos: planilha ? centavosDeValor(planilha.salarioBruto) : 0,
  });

  const corpo = document.createElement('div');
  corpo.appendChild(nome.wrapper);
  corpo.appendChild(salario.wrapper);

  const aviso = document.createElement('div');
  aviso.hidden = true;
  aviso.className = 'erro';
  corpo.appendChild(aviso);

  function aoSubmeter() {
    const nomeValor = nome.input.value.trim();
    if (!nomeValor) {
      aviso.textContent = 'Informe um nome para a planilha.';
      aviso.hidden = false;
      nome.input.focus();
      return;
    }
    const cent = obterCentavos(salario.input);
    if (cent < 0) return;
    if (typeof onSalvar === 'function') onSalvar({ nome: nomeValor, salarioBruto: valorDeCentavos(cent) });
  }

  const submeter = document.createElement('form');
  submeter.addEventListener('submit', (e) => {
    e.preventDefault();
    aoSubmeter();
  });
  submeter.appendChild(corpo);

  abrirModal({
    titulo,
    sub,
    corpo: submeter,
    largura: 460,
    rodape: [
      botao({ label: 'Cancelar', onClick: fecharModal }),
      botao({
        label: planilha ? 'Salvar alterações' : 'Criar planilha',
        primario: true,
        onClick: aoSubmeter,
      }),
    ],
  });

  nome.input.focus();
}

export function formularioDespesa({ despesa, onSalvar }) {
  const editando = !!despesa;
  const titulo = editando ? 'Editar despesa' : 'Adicionar despesa';
  const sub = 'Registre os detalhes da despesa.';

  const nome = campoTexto({
    id: 'f-nome-despesa',
    label: 'Nome da despesa',
    placeholder: 'Ex.: Faculdade',
    valor: editando ? despesa.nome : '',
    autofoco: !editando,
  });

  const valor = campoDinheiro({
    id: 'f-valor-despesa',
    label: 'Valor',
    placeholder: 'R$ 0,00',
    autofoco: editando,
    valorCentavos: editando ? centavosDeValor(despesa.valor) : 0,
  });

  const corpo = document.createElement('div');
  corpo.appendChild(nome.wrapper);
  corpo.appendChild(valor.wrapper);

  const aviso = document.createElement('div');
  aviso.hidden = true;
  aviso.className = 'erro';
  corpo.appendChild(aviso);

  function aoSubmeter() {
    const nomeValor = nome.input.value.trim();
    if (!nomeValor) {
      aviso.textContent = 'Informe o nome da despesa.';
      aviso.hidden = false;
      nome.input.focus();
      return;
    }
    const cent = obterCentavos(valor.input);
    if (cent <= 0) {
      aviso.textContent = 'Informe um valor maior que zero.';
      aviso.hidden = false;
      valor.input.focus();
      return;
    }
    if (typeof onSalvar === 'function') {
      onSalvar({ nome: nomeValor, valor: valorDeCentavos(cent) });
    }
  }

  const submeter = document.createElement('form');
  submeter.addEventListener('submit', (e) => {
    e.preventDefault();
    aoSubmeter();
  });
  submeter.appendChild(corpo);

  abrirModal({
    titulo,
    sub,
    corpo: submeter,
    largura: 460,
    rodape: [
      botao({ label: 'Cancelar', onClick: fecharModal }),
      botao({
        label: editando ? 'Salvar alterações' : 'Adicionar despesa',
        primario: true,
        onClick: aoSubmeter,
      }),
    ],
  });

  nome.input.focus();
}