export const fmtBRL = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

const fmtInt = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 });

export function formatarValor(valor) {
  return fmtBRL.format(Number(valor) || 0);
}

export function centavosDeValor(valor) {
  return Math.round((Number(valor) || 0) * 100);
}

function partesDoTexto(texto) {
  const semMoeda = String(texto || '').replace(/[^\d,]/g, '');
  const [parteInt = '', parteDec = ''] = semMoeda.split(',');
  return {
    intRaw: parteInt.replace(/\D/g, ''),
    decRaw: parteDec.replace(/\D/g, '').slice(0, 2),
    temComma: semMoeda.includes(','),
  };
}

function centavosDoTexto(texto) {
  const p = partesDoTexto(texto);
  const r = parseInt(p.intRaw || '0', 10);
  const c = parseInt((p.decRaw + '00').slice(0, 2), 10);
  return r * 100 + c;
}

function textoDeCentavos(texto) {
  const p = partesDoTexto(texto);
  const cent = centavosDoTexto(texto);
  const reais = Math.floor(cent / 100);
  const dec = cent % 100;
  const reaisFormatados = fmtInt.format(reais);
  if (!p.temComma) return 'R$ ' + reaisFormatados;
  return 'R$ ' + reaisFormatados + ',' + String(dec).padStart(2, '0');
}

function formatoCompleto(cent) {
  const reais = Math.floor(cent / 100);
  const dec = cent % 100;
  return 'R$ ' + fmtInt.format(reais) + ',' + String(dec).padStart(2, '0');
}

export function vincularCampoDinheiro(input) {
  if (!input || input.dataset.dinheiro) return input;

  input.dataset.dinheiro = '1';
  input.setAttribute('inputmode', 'numeric');
  input.setAttribute('autocomplete', 'off');
  input.spellcheck = false;

  input.addEventListener('input', () => {
    input.value = textoDeCentavos(input.value);
  });

  input.addEventListener('focus', () => {
    if (input.value) requestAnimationFrame(() => input.select());
  });

  input.addEventListener('blur', () => {
    const cent = centavosDoTexto(input.value);
    input.value = cent > 0 ? formatoCompleto(cent) : '';
  });

  return input;
}

export function obterCentavos(input) {
  return centavosDoTexto(input.value);
}

export function definirCentavos(input, cent) {
  const valor = Math.round(Number(cent) || 0);
  input.value = valor > 0 ? formatoCompleto(valor) : '';
  return input;
}

export function valorDeCentavos(cent) {
  return Math.round(Number(cent) || 0) / 100;
}