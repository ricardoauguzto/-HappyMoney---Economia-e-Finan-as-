import { api } from '../api.js';
import { icone } from '../icons.js';
import { formatarValor } from '../money.js';
import { calcular } from '../../shared/finance.js';
import { confirmar, toast, dialogar, fecharModal } from '../ui.js';
import { formularioDespesa, formularioPlanilha } from './formularios.js';

export function renderizarPlanilha(tela, ctx) {
  const estado = ctx.estado;
  if (!estado.sheet) {
    ctx.irPara('dashboard');
    return;
  }

  estado.dirty = false;

  tela.innerHTML = '';

  const wraper = document.createElement('div');
  wraper.className = 'wraper animar-tela';
  tela.appendChild(wraper);

  const barra = document.createElement('div');
  barra.className = 'pl-barra';

  const btnVoltar = document.createElement('button');
  btnVoltar.type = 'button';
  btnVoltar.className = 'btn btn-suave';
  btnVoltar.innerHTML = icone('setaEsq') + 'Voltar';
  btnVoltar.addEventListener('click', voltarComAlerta);

  const tituloCaixa = document.createElement('div');
  tituloCaixa.className = 'pl-titulo-caixa';

  const titulo = document.createElement('h1');
  titulo.className = 'pl-titulo';
  titulo.textContent = estado.sheet.nome;

  const statusPill = document.createElement('span');
  statusPill.className = 'pill pill-verde';
  statusPill.id = 'status-pill';
  statusPill.innerHTML = icone('checado') + 'Salvo';

  tituloCaixa.appendChild(titulo);
  tituloCaixa.appendChild(statusPill);

  const btnSalvar = document.createElement('button');
  btnSalvar.type = 'button';
  btnSalvar.className = 'btn btn-primario';
  btnSalvar.innerHTML = icone('checado') + 'Salvar';
  btnSalvar.addEventListener('click', () => salvar());

  barra.appendChild(btnVoltar);
  barra.appendChild(tituloCaixa);
  barra.appendChild(btnSalvar);
  wraper.appendChild(barra);

  const grade = document.createElement('div');
  grade.className = 'grade-planilha';

  const cardSalario = document.createElement('section');
  cardSalario.className = 'card card-salario';
  cardSalario.innerHTML =
    '<div class="pl-topo">' +
    '<span class="rotulo-menor">Salário bruto</span>' +
    '<button type="button" data-editar-salario class="icon-btn ghost" title="Editar nome ou salário">' +
    icone('lapis') +
    '</button>' +
    '</div>' +
    '<div class="valor-gigante" id="valor-salario"></div>';
  cardSalario
    .querySelector('[data-editar-salario]')
    .addEventListener('click', editarSalario);
  grade.appendChild(cardSalario);

  const cardComprometido = document.createElement('section');
  cardComprometido.className = 'card card-comprometido';
  cardComprometido.id = 'card-comprometido';
  grade.appendChild(cardComprometido);

  wraper.appendChild(grade);

  const cardDespesas = document.createElement('section');
  cardDespesas.className = 'card card-despesas';

  const despCabecalho = document.createElement('div');
  despCabecalho.className = 'desp-cabecalho';
  despCabecalho.innerHTML =
    '<h2 style="margin:0;font-size:18px;font-weight:750">Despesas</h2>' +
    '<span class="pill pill-suave" id="qtd-despesas"></span>';
  cardDespesas.appendChild(despCabecalho);

  const lista = document.createElement('ul');
  lista.className = 'lista-despesas';
  lista.id = 'lista-despesas';
  cardDespesas.appendChild(lista);

  const resumo = document.createElement('div');
  resumo.className = 'resumo-despesas';
  resumo.innerHTML =
    '<span class="rotulo">Total das despesas</span>' +
    '<span class="valor" id="total-despesas"></span>';
  cardDespesas.appendChild(resumo);

  const btnAdicionar = document.createElement('button');
  btnAdicionar.type = 'button';
  btnAdicionar.className = 'botao-adicionar';
  btnAdicionar.innerHTML = icone('mais') + 'Adicionar despesa';
  btnAdicionar.addEventListener('click', adicionarDespesa);
  cardDespesas.appendChild(btnAdicionar);

  wraper.appendChild(cardDespesas);

  const hero = document.createElement('section');
  hero.className = 'card card-hero';
  hero.innerHTML =
    '<div class="hero-rotulo">Salário do mês</div>' +
    '<div class="hero-valor" id="hero-valor"></div>' +
    '<div class="hero-status" id="hero-status"></div>' +
    '<div class="hero-grafico">' +
    '<div class="barra-progresso"><div class="preenchimento" id="barra-preenchimento"></div></div>' +
    '<div class="hero-linhas" id="hero-linhas"></div>' +
    '</div>';
  wraper.appendChild(hero);

  function marcarSujo() {
    if (estado.dirty) return;
    estado.dirty = true;
    statusPill.className = 'pill pill-ambar';
    statusPill.innerHTML = icone('info') + 'Alterações não salvas';
  }

  function atualizarTudo() {
    const r = calcular(estado.sheet);

    document.getElementById('valor-salario').textContent = formatarValor(r.salarioBruto);
    document.getElementById('qtd-despesas').textContent =
      r.qtdDespesas === 1 ? '1 despesa' : r.qtdDespesas + ' despesas';
    document.getElementById('total-despesas').textContent = formatarValor(r.total);

    const heroValor = document.getElementById('hero-valor');
    heroValor.textContent = formatarValor(r.disponivel);

    const heroStatus = document.getElementById('hero-status');
    heroStatus.className =
      r.situacao === 'negativo'
        ? 'hero-status hero-status-neg'
        : 'hero-status';
    heroStatus.textContent =
      r.situacao === 'negativo'
        ? 'Acima do salário — atenção'
        : 'Disponível';

    document.getElementById('barra-preenchimento').style.width =
      Math.max(0, Math.min(100, r.disponivelPct)) + '%';

    document.getElementById('hero-linhas').innerHTML =
      '<span><b id="pct-disponivel"></b> disponível</span>' +
      '<span><b id="pct-comprometido"></b> do salário comprometido</span>' +
      '<span><b>' + r.qtdDespesas + '</b> despesas no total</span>';
    document.getElementById('pct-disponivel').textContent =
      Math.round(r.disponivelPct) + '%';
    document.getElementById('pct-comprometido').textContent =
      Math.round(r.comprometidoPct) + '%';

    document.getElementById('card-comprometido').innerHTML =
      '<span class="rotulo-menor">Despesas do mês</span>' +
      '<div class="valor">' + formatarValor(r.total) + '</div>' +
      '<div class="linha-menor"><span>Comprometido</span><b>' +
      Math.round(r.comprometidoPct) +
      '%</b></div>' +
      '<div class="barra-progresso track-claro" style="margin-top:12px">' +
      '<div class="preenchimento" style="width:' +
      Math.max(0, Math.min(100, r.comprometidoPct)) +
      '%"></div></div>';

    titulo.textContent = estado.sheet.nome;
  }

  function renderizarLista() {
    const ul = document.getElementById('lista-despesas');
    ul.innerHTML = '';

    if (estado.sheet.despesas.length === 0) {
      const vazio = document.createElement('li');
      vazio.className = 'desp-vazio';
      vazio.innerHTML =
        '<span class="vazio-emoji">🧾</span>Nenhuma despesa cadastrada ainda.';
      ul.appendChild(vazio);
      return;
    }

    estado.sheet.despesas.forEach((despesa, indice) => {
      const item = document.createElement('li');
      item.className = 'despesa';
      item.innerHTML =
        '<div class="desp-icone">' + icone('recibo') + '</div>' +
        '<div class="desp-info"><span class="desp-nome"></span>' +
        '<span class="desp-ordem">Despesa ' + (indice + 1) + '</span></div>' +
        '<span class="desp-valor"></span>' +
        '<div class="desp-acoes">' +
        '<button type="button" data-editar class="icon-btn ghost" title="Editar despesa">' +
        icone('lapis') +
        '</button>' +
        '<button type="button" data-excluir class="icon-btn ghost perigo" title="Excluir despesa">' +
        icone('lixeira') +
        '</button>' +
        '</div>';

      item.querySelector('.desp-nome').textContent = despesa.nome || 'Despesa';
      item.querySelector('.desp-valor').textContent = formatarValor(despesa.valor);

      item.querySelector('[data-editar]').addEventListener('click', () =>
        editarDespesa(despesa)
      );
      item.querySelector('[data-excluir]').addEventListener('click', () =>
        excluirDespesa(despesa)
      );

      ul.appendChild(item);
    });
  }

  function adicionarDespesa() {
    formularioDespesa({
      onSalvar: (dados) => {
        estado.sheet.despesas.push({ ...dados, id: novoId() });
        fecharModal();
        marcarSujo();
        renderizarLista();
        atualizarTudo();
        toast('Despesa adicionada.');
      },
    });
  }

  function editarDespesa(despesa) {
    formularioDespesa({
      despesa,
      onSalvar: (dados) => {
        Object.assign(despesa, dados);
        fecharModal();
        marcarSujo();
        renderizarLista();
        atualizarTudo();
        toast('Despesa atualizada.');
      },
    });
  }

  function excluirDespesa(despesa) {
    confirmar({
      titulo: 'Excluir despesa',
      mensagem:
        'A despesa "' +
        (despesa.nome || 'sem nome') +
        '" será removida desta planilha. Continuar?',
      okLabel: 'Excluir',
      onOk: () => {
        estado.sheet.despesas = estado.sheet.despesas.filter(
          (d) => d.id !== despesa.id
        );
        marcarSujo();
        renderizarLista();
        atualizarTudo();
        toast('Despesa excluída.');
      },
    });
  }

  function editarSalario() {
    formularioPlanilha({
      planilha: estado.sheet,
      onSalvar: (dados) => {
        estado.sheet.nome = dados.nome;
        estado.sheet.salarioBruto = dados.salarioBruto;
        fecharModal();
        marcarSujo();
        atualizarTudo();
        toast('Planilha atualizada.');
      },
    });
  }

  function voltarComAlerta() {
    if (estado.dirty) {
      dialogar({
        titulo: 'Salvar alterações?',
        mensagem:
          'Você fez alterações nesta planilha que ainda não foram salvas.',
        opcoes: [
          { label: 'Cancelar' },
          { label: 'Descartar', perigo: true, onClick: () => ctx.irPara('dashboard') },
          {
            label: 'Salvar',
            primario: true,
            onClick: async () => {
              const ok = await salvar();
              if (ok) ctx.irPara('dashboard');
            },
          },
        ],
      });
      return;
    }
    ctx.irPara('dashboard');
  }

  async function salvar() {
    try {
      const copia = {
        ...estado.sheet,
        despesas: estado.sheet.despesas.map((d) => ({ ...d })),
      };
      const resultado = await api.salvarPlanilha({
        sheet: copia,
        caminho: estado.caminho,
      });
      estado.sheet = resultado.sheet;
      estado.caminho = resultado.caminho;
      estado.dirty = false;
      statusPill.className = 'pill pill-verde';
      statusPill.innerHTML = icone('checado') + 'Salvo';
      toast('Planilha salva.');
      return true;
    } catch (err) {
      toast(err.message || 'Não foi possível salvar.', 'erro');
      return false;
    }
  }

  renderizarLista();
  atualizarTudo();
}

function novoId() {
  return globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function'
    ? globalThis.crypto.randomUUID()
    : 'id-' + Date.now().toString(36) + '-' + Math.random().toString(16).slice(2);
}